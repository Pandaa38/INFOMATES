#include <iostream>
#include <vector>
#include <stack>
#include <list>
#include <unordered_map>

using namespace std;

// Grafo no dirigido usando listas de adyacencia
class Grafo {
private:
    int V; // Número de vértices
    unordered_map<int, list<int>> adyacente; // Mapa de adyacencias

public:
    Grafo(int V) : V(V) {}

    void agregarArista(int u, int v) {
        adyacente[u].push_back(v);
        adyacente[v].push_back(u); // No dirigido
    }

    void removerArista(int u, int v) {
        adyacente[u].remove(v);
        adyacente[v].remove(u);
    }

    vector<int> circuitoEuler(int inicio) {
        stack<int> pila;
        vector<int> circuito;
        int actual = inicio;

        while (!pila.empty() || !adyacente[actual].empty()) {
            if (adyacente[actual].empty()) {
                circuito.push_back(actual);
                actual = pila.top(); pila.pop();
            } else {
                pila.push(actual);
                int siguiente = adyacente[actual].front();
                removerArista(actual, siguiente);
                actual = siguiente;
            }
        }

        circuito.push_back(actual); // Agregar el último
        return circuito;
    }
};

// Ejemplo de uso
int main() {
    Grafo g(6);

    // Grafo de Euler simple
    g.agregarArista(1, 2);
    g.agregarArista(1, 3);
    g.agregarArista(2, 3);
    g.agregarArista(2, 4);
    g.agregarArista(2, 5);
    g.agregarArista(3, 4);
    g.agregarArista(3, 5);
    g.agregarArista(4, 5);
    g.agregarArista(4, 6);
    g.agregarArista(6, 5);

    vector<int> circuito = g.circuitoEuler(1);

    cout << "Circuito de Euler: ";
    for (int v : circuito) {
        cout << v << " ";
    }
    cout << endl;

    return 0;
}

