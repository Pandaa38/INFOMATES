#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

pair<vector<int>, int> cargarContenedores(vector<int>& pesos, int capacidad) {   
    sort(pesos.begin(), pesos.end(), greater<int>());
    vector<int> seleccionados;
    int cargaTotal = 0;
    for (int peso : pesos) {
        if (cargaTotal + peso <= capacidad) {
            seleccionados.push_back(peso);
            cargaTotal += peso;
        }
    }
    return {seleccionados, cargaTotal};
}

int main() {
    vector<int> pesos = {7, 2, 10, 3, 5};
    int capacidad = 15;
    auto resultado = cargarContenedores(pesos, capacidad);
    vector<int> seleccionados = resultado.first;
    int cargaTotal = resultado.second;
    cout << "Contenedores seleccionados: ";
    for (int peso : seleccionados) {
        cout << peso << " ";
    } 
    cout << "\nCarga total: " << cargaTotal << " toneladas" << endl;
    return 0;
}

