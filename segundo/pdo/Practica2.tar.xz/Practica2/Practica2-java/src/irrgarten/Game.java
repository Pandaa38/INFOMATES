
package irrgarten;

import java.util.ArrayList;

/**
 *
 * @author juan
 */
public class Game {
    private static final int MAXROUNDS = 10;
    
    private int carrentPlayerIndex;
    private String log;
    
    private ArrayList<Player> players;
    private ArrayList<Monster> monsters;
    
    private Player currentPlayer;
    private Labyrinth labyrinth;
    
    Game(int nplayers){
        players = new A
    }
    
    
}
